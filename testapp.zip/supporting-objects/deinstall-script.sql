begin
    execute immediate 'drop package map_route_api';
exception
    when others then
        if sqlcode != -4043 then
            raise;
        end if;
end;
/

begin
    execute immediate 'drop table map_route_points purge';
exception
    when others then
        if sqlcode != -942 then
            raise;
        end if;
end;
/

begin
    execute immediate 'drop table map_routes purge';
exception
    when others then
        if sqlcode != -942 then
            raise;
        end if;
end;
/
