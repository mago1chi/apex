(function ($, apex) {
    "use strict";

    const configuredRegionId = "route-map";
    const mapRegionDomIdItem = "P3_MAP_REGION_DOM_ID";
    const pointSourceId = "route-map-edit-points";
    const pointLayerId = "route-map-edit-point-layer";
    const routeSourceId = "route-map-edit-route";
    const routeLayerId = "route-map-edit-route-layer";

    let initialized = false;
    let mapRegion = null;
    let mapObject = null;
    let mapEventsBound = false;
    let points = [];
    let routeFeature = null;

    function item(name) {
        return apex.item(name);
    }

    function itemValue(name) {
        const pageItem = item(name);
        return pageItem && pageItem.getValue ? pageItem.getValue() : "";
    }

    function setItemValue(name, value) {
        const pageItem = item(name);
        if (pageItem && pageItem.setValue) {
            pageItem.setValue(value || "", null, true);
        }
    }

    function readJson(value, fallback) {
        if (!value) {
            return fallback;
        }
        try {
            return JSON.parse(value);
        }
        catch (error) {
            return fallback;
        }
    }

    function normalizePoints(rawPoints) {
        return (rawPoints || [])
            .map((point, index) => ({
                id: point.id || `client-${Date.now()}-${index}`,
                seq: index + 1,
                lat: Number(point.lat),
                lng: Number(point.lng),
                note: point.note || ""
            }))
            .filter((point) => Number.isFinite(point.lat) && Number.isFinite(point.lng));
    }

    function pointsFeatureCollection() {
        return {
            type: "FeatureCollection",
            features: points.map((point) => ({
                type: "Feature",
                id: point.id,
                properties: {
                    seq: point.seq,
                    note: point.note
                },
                geometry: {
                    type: "Point",
                    coordinates: [point.lng, point.lat]
                }
            }))
        };
    }

    function routeFeatureCollection() {
        return {
            type: "FeatureCollection",
            features: routeFeature ? [routeFeature] : []
        };
    }

    function syncItems() {
        const payload = points.map((point, index) => ({
            id: point.id,
            seq: index + 1,
            lat: point.lat,
            lng: point.lng,
            note: point.note || ""
        }));

        setItemValue("P3_POINTS_JSON", JSON.stringify(payload));
        setItemValue("P3_ROUTE_GEOJSON", routeFeature ? JSON.stringify(routeFeature) : "");
    }

    function showError(message) {
        apex.message.clearErrors();
        apex.message.showErrors([{
            type: "error",
            location: "page",
            message,
            unsafe: false
        }]);
    }

    function escapeSelector(value) {
        if ($.escapeSelector) {
            return $.escapeSelector(value);
        }
        return String(value).replace(/([ !"#$%&'()*+,./:;<=>?@[\]^`{|}~])/g, "\\$1");
    }

    function mapRegionIdCandidates() {
        const ids = [
            configuredRegionId,
            itemValue(mapRegionDomIdItem)
        ];
        return ids
            .filter((id) => id && typeof id === "string")
            .filter((id, index, values) => values.indexOf(id) === index);
    }

    function getApexRegion(regionId) {
        if (!regionId) {
            return null;
        }

        try {
            const region = apex.region(regionId);
            if (region && (region.getMapObject || region.getMapCenterAndZoomLevel)) {
                return region;
            }
        }
        catch (error) {
            return null;
        }

        return null;
    }

    function findMapRegionFromDom() {
        const selectors = [
            ".a-MapRegion",
            ".maplibregl-map",
            ".mapboxgl-map"
        ];

        for (const selector of selectors) {
            const node = $(selector).first();
            if (!node.length) {
                continue;
            }

            let regionElement = node.closest("[id]");
            while (regionElement.length) {
                const region = getApexRegion(regionElement.attr("id"));
                if (region) {
                    return region;
                }
                regionElement = regionElement.parent().closest("[id]");
            }
        }

        return null;
    }

    function resolveMapRegion() {
        if (mapRegion && (mapRegion.getMapObject || mapRegion.getMapCenterAndZoomLevel)) {
            return mapRegion;
        }

        for (const regionId of mapRegionIdCandidates()) {
            const region = getApexRegion(regionId);
            if (region) {
                mapRegion = region;
                return mapRegion;
            }
        }

        mapRegion = findMapRegionFromDom();
        return mapRegion;
    }

    function bindMapObjectEvents() {
        if (!mapObject || mapEventsBound) {
            return;
        }

        mapObject.off("contextmenu", handleMapContextMenu);
        mapObject.on("contextmenu", handleMapContextMenu);
        mapObject.on("load", updateMap);
        mapObject.on("styledata", updateMap);
        mapEventsBound = true;
    }

    function resolveMapObject() {
        if (mapObject && mapObject.getCenter) {
            return mapObject;
        }

        const region = resolveMapRegion();
        if (!region || !region.getMapObject) {
            return null;
        }

        const resolvedMapObject = region.getMapObject();
        if (!resolvedMapObject) {
            return null;
        }

        if (mapObject !== resolvedMapObject) {
            mapObject = resolvedMapObject;
            mapEventsBound = false;
        }
        bindMapObjectEvents();
        return mapObject;
    }

    function ensureMapLayers() {
        resolveMapObject();
        if (!mapObject || !mapObject.isStyleLoaded()) {
            return false;
        }

        if (!mapObject.getSource(routeSourceId)) {
            mapObject.addSource(routeSourceId, {
                type: "geojson",
                data: routeFeatureCollection()
            });
        }
        if (!mapObject.getLayer(routeLayerId)) {
            mapObject.addLayer({
                id: routeLayerId,
                type: "line",
                source: routeSourceId,
                paint: {
                    "line-color": "#2563EB",
                    "line-width": 5,
                    "line-opacity": 0.8
                }
            });
        }

        if (!mapObject.getSource(pointSourceId)) {
            mapObject.addSource(pointSourceId, {
                type: "geojson",
                data: pointsFeatureCollection()
            });
        }
        if (!mapObject.getLayer(pointLayerId)) {
            mapObject.addLayer({
                id: pointLayerId,
                type: "circle",
                source: pointSourceId,
                paint: {
                    "circle-radius": 8,
                    "circle-color": "#DC2626",
                    "circle-stroke-color": "#FFFFFF",
                    "circle-stroke-width": 2
                }
            });
        }

        return true;
    }

    function updateMap() {
        syncItems();
        if (!ensureMapLayers()) {
            return;
        }

        mapObject.getSource(pointSourceId).setData(pointsFeatureCollection());
        mapObject.getSource(routeSourceId).setData(routeFeatureCollection());
    }

    function formatDuration(seconds) {
        const totalMinutes = Math.max(1, Math.round((Number(seconds) || 0) / 60));
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;

        if (hours > 0 && minutes > 0) {
            return `${hours}時間${minutes}分`;
        }
        if (hours > 0) {
            return `${hours}時間`;
        }
        return `${minutes}分`;
    }

    function formatDistance(meters) {
        const distance = Number(meters) || 0;
        if (distance >= 1000) {
            return `${(distance / 1000).toFixed(1)} km`;
        }
        return `${Math.round(distance)} m`;
    }

    function pointLabel(point, index) {
        const note = (point && point.note ? String(point.note).trim() : "");
        return note || `ピン${index + 1}`;
    }

    function routeSegments() {
        const properties = routeFeature && routeFeature.properties ? routeFeature.properties : {};
        return Array.isArray(properties.segments) ? properties.segments : [];
    }

    function renderSegmentList() {
        if (points.length < 2) {
            return "";
        }

        const segments = routeSegments();
        if (!segments.length) {
            return '<p class="route-map-empty">経路再計算後に区間ごとの移動時間を表示します。</p>';
        }

        const totalDuration = segments.reduce((sum, segment) => sum + (Number(segment.duration) || 0), 0);
        const totalDistance = segments.reduce((sum, segment) => sum + (Number(segment.distance) || 0), 0);
        const rows = segments.map((segment, index) => {
            const fromPoint = points[index];
            const toPoint = points[index + 1];
            const fromLabel = apex.util.escapeHTML(pointLabel(fromPoint, index));
            const toLabel = apex.util.escapeHTML(pointLabel(toPoint, index + 1));

            return `<tr>
                <td>${index + 1} - ${index + 2}</td>
                <td class="route-map-label-cell">${fromLabel}</td>
                <td class="route-map-label-cell">${toLabel}</td>
                <td>${formatDistance(segment.distance)}</td>
                <td>${formatDuration(segment.duration)}</td>
            </tr>`;
        }).join("");

        return `<h3 class="route-map-segments-title">区間別移動時間</h3>
            <div class="route-map-table-wrap">
                <table class="t-Report-report route-map-segments-table">
                    <colgroup>
                        <col style="width: 20%;">
                        <col style="width: 20%;">
                        <col style="width: 20%;">
                        <col style="width: 20%;">
                        <col style="width: 20%;">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>区間</th>
                            <th>出発</th>
                            <th>到着</th>
                            <th>距離</th>
                            <th>移動時間</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3">合計</th>
                            <th>${formatDistance(totalDistance)}</th>
                            <th>${formatDuration(totalDuration)}</th>
                        </tr>
                    </tfoot>
                </table>
            </div>`;
    }

    function renderPointList() {
        const container = $("#route-map-point-list");

        if (!points.length) {
            container.html('<p class="route-map-empty">地図を目的の場所へ移動して「地図中心にピン追加」を押してください。</p>');
            return;
        }

        const rows = points.map((point, index) => {
            const safeNote = apex.util.escapeHTML(point.note || "");
            return `<tr>
                <td>${index + 1}</td>
                <td>${point.lat.toFixed(5)}<br>${point.lng.toFixed(5)}</td>
                <td class="route-map-label-cell">${safeNote}</td>
                <td>
                    <div class="route-map-actions">
                        <button type="button" class="t-Button t-Button--noLabel t-Button--icon" title="上へ" data-action="up" data-index="${index}"><span class="fa fa-arrow-up" aria-hidden="true"></span></button>
                        <button type="button" class="t-Button t-Button--noLabel t-Button--icon" title="下へ" data-action="down" data-index="${index}"><span class="fa fa-arrow-down" aria-hidden="true"></span></button>
                        <button type="button" class="t-Button t-Button--noLabel t-Button--icon" title="編集" data-action="edit" data-index="${index}"><span class="fa fa-edit" aria-hidden="true"></span></button>
                        <button type="button" class="t-Button t-Button--noLabel t-Button--icon" title="削除" data-action="delete" data-index="${index}"><span class="fa fa-trash" aria-hidden="true"></span></button>
                    </div>
                </td>
            </tr>`;
        }).join("");

        container.html(`<div class="route-map-table-wrap">
            <table class="t-Report-report route-map-points-table">
                <colgroup>
                    <col style="width: 25%;">
                    <col style="width: 25%;">
                    <col style="width: 25%;">
                    <col style="width: 25%;">
                </colgroup>
                <thead>
                    <tr>
                        <th>順序</th>
                        <th>位置</th>
                        <th>備考</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>${renderSegmentList()}`);
    }

    function refreshUi() {
        points = points.map((point, index) => ({
            ...point,
            seq: index + 1
        }));
        renderPointList();
        updateMap();
    }

    function addPoint(lat, lng) {
        const note = window.prompt("この場所の備考を入力してください。", "");
        points.push({
            id: `client-${Date.now()}-${points.length + 1}`,
            seq: points.length + 1,
            lat: Number(lat),
            lng: Number(lng),
            note: note || ""
        });
        refreshUi();
        recalculateRoute();
    }

    function extractClickPosition(data) {
        const payload = data || {};
        const lngLat = payload.lngLat || payload.lnglat || payload.coordinates || {};
        const detail = payload.detail || {};
        const detailLngLat = detail.lngLat || detail.lnglat || {};

        const lat = Number(
            payload.lat ??
            payload.latitude ??
            lngLat.lat ??
            lngLat.latitude ??
            detail.lat ??
            detail.latitude ??
            detailLngLat.lat ??
            detailLngLat.latitude
        );
        const lng = Number(
            payload.lng ??
            payload.lon ??
            payload.longitude ??
            lngLat.lng ??
            lngLat.lon ??
            lngLat.longitude ??
            detail.lng ??
            detail.lon ??
            detail.longitude ??
            detailLngLat.lng ??
            detailLngLat.lon ??
            detailLngLat.longitude
        );

        if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
            return null;
        }

        return { lat, lng };
    }

    function addPointFromMapClick(data) {
        const position = extractClickPosition(data);
        if (!position) {
            showError("地図の右クリック位置を取得できませんでした。");
            return;
        }

        addPoint(position.lat, position.lng);
    }

    function addPointAtCenter() {
        resolveMapObject();
        if (!mapObject || !mapObject.getCenter) {
            showError("地図の準備が完了していません。少し待ってから再実行してください。");
            return;
        }

        const center = mapObject.getCenter();
        addPoint(center.lat, center.lng);
    }

    function validateLatLng(lat, lng) {
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
            showError("緯度と経度を数値で入力してください。");
            return false;
        }
        if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
            showError("緯度は-90から90、経度は-180から180の範囲で入力してください。");
            return false;
        }
        return true;
    }

    function centerMapAt(lat, lng, zoomLevel) {
        resolveMapObject();
        if (!mapObject) {
            showError("地図の準備が完了していません。少し待ってから再実行してください。");
            return false;
        }

        const center = [lng, lat];
        const currentZoom = mapObject.getZoom ? mapObject.getZoom() : 0;
        const zoom = Math.max(currentZoom || 0, zoomLevel || 15);

        if (mapObject.flyTo) {
            mapObject.flyTo({
                center,
                zoom,
                essential: true
            });
        }
        else {
            if (mapObject.setCenter) {
                mapObject.setCenter(center);
            }
            if (mapObject.setZoom) {
                mapObject.setZoom(zoom);
            }
        }

        return true;
    }

    function addPointFromManualInput() {
        const lat = Number(itemValue("P3_PIN_LATITUDE"));
        const lng = Number(itemValue("P3_PIN_LONGITUDE"));

        if (!validateLatLng(lat, lng)) {
            return;
        }

        centerMapAt(lat, lng, 15);
        addPoint(lat, lng);
    }

    function searchPlace() {
        const query = String(itemValue("P3_SEARCH_QUERY") || "").trim();
        if (!query) {
            showError("検索する施設名または地名を入力してください。");
            return Promise.resolve();
        }

        const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=ja&q=${encodeURIComponent(query)}`;

        return fetch(url)
            .then((response) => {
                if (!response.ok) {
                    throw new Error(`検索API HTTP ${response.status}`);
                }
                return response.json();
            })
            .then((results) => {
                if (!results || !results.length) {
                    showError("該当する場所が見つかりませんでした。検索語を変えて再実行してください。");
                    return;
                }

                const result = results[0];
                const lat = Number(result.lat);
                const lng = Number(result.lon);
                if (!validateLatLng(lat, lng)) {
                    return;
                }

                if (centerMapAt(lat, lng, 15)) {
                    apex.message.clearErrors();
                    apex.message.showPageSuccess(`地図を「${apex.util.escapeHTML(result.display_name || query)}」に移動しました。`);
                }
            })
            .catch((error) => {
                showError(`場所検索に失敗しました。${error.message}`);
            });
    }

    function handleMapContextMenu(event) {
        if (event.preventDefault) {
            event.preventDefault();
        }
        if (event.originalEvent && event.originalEvent.preventDefault) {
            event.originalEvent.preventDefault();
        }

        addPointFromMapClick(event);
    }

    function editPoint(index) {
        const point = points[index];
        if (!point) {
            return;
        }
        const note = window.prompt("備考を編集してください。", point.note || "");
        if (note !== null) {
            point.note = note;
            refreshUi();
        }
    }

    function movePoint(index, direction) {
        const targetIndex = index + direction;
        if (targetIndex < 0 || targetIndex >= points.length) {
            return;
        }

        const temp = points[index];
        points[index] = points[targetIndex];
        points[targetIndex] = temp;
        refreshUi();
        recalculateRoute();
    }

    function deletePoint(index) {
        points.splice(index, 1);
        refreshUi();
        recalculateRoute();
    }

    function handlePointListClick(event) {
        const button = $(event.target).closest("button[data-action]");
        if (!button.length) {
            return;
        }

        const index = Number(button.attr("data-index"));
        const action = button.attr("data-action");

        if (action === "up") {
            movePoint(index, -1);
        }
        else if (action === "down") {
            movePoint(index, 1);
        }
        else if (action === "edit") {
            editPoint(index);
        }
        else if (action === "delete") {
            deletePoint(index);
        }
    }

    function osrmCoordinates() {
        return points
            .map((point) => `${point.lng},${point.lat}`)
            .join(";");
    }

    function recalculateRoute() {
        if (points.length < 2) {
            routeFeature = null;
            refreshUi();
            return Promise.resolve();
        }

        const url = `https://router.project-osrm.org/route/v1/driving/${osrmCoordinates()}?overview=full&geometries=geojson`;

        return fetch(url)
            .then((response) => {
                if (!response.ok) {
                    throw new Error(`OSRM HTTP ${response.status}`);
                }
                return response.json();
            })
            .then((data) => {
                if (!data.routes || !data.routes.length || !data.routes[0].geometry) {
                    throw new Error("OSRMから経路が返されませんでした。");
                }

                const route = data.routes[0];
                const segments = (route.legs || []).map((leg, index) => ({
                    seq: index + 1,
                    fromSeq: index + 1,
                    toSeq: index + 2,
                    distance: leg.distance,
                    duration: leg.duration
                }));

                routeFeature = {
                    type: "Feature",
                    properties: {
                        provider: "OSRM",
                        profile: "driving",
                        distance: route.distance,
                        duration: route.duration,
                        segments
                    },
                    geometry: route.geometry
                };
                refreshUi();
                apex.message.showPageSuccess("経路を再計算しました。");
            })
            .catch((error) => {
                routeFeature = null;
                refreshUi();
                showError(`経路計算に失敗しました。ピンは保存できます。${error.message}`);
            });
    }

    function resetRoute() {
        setItemValue("P3_ROUTE_ID", "");
        setItemValue("P3_ROUTE_NAME", "");
        setItemValue("P3_ROUTE_DESCRIPTION", "");
        points = [];
        routeFeature = null;
        refreshUi();
        apex.message.clearErrors();
    }

    function initializeState() {
        points = normalizePoints(readJson(itemValue("P3_POINTS_JSON"), []));
        routeFeature = readJson(itemValue("P3_ROUTE_GEOJSON"), null);
        refreshUi();
    }

    function bindEvents() {
        $("#route-map-point-list").off("click.routeMap").on("click.routeMap", handlePointListClick);
        $(document).off("apexbeforepagesubmit.routeMap").on("apexbeforepagesubmit.routeMap", syncItems);

        mapRegionIdCandidates().forEach((regionId) => {
            $(`#${escapeSelector(regionId)}`).off("spatialmapinitialized.routeMap").on("spatialmapinitialized.routeMap", function () {
                mapRegion = getApexRegion(regionId);
                mapObject = mapRegion && mapRegion.getMapObject ? mapRegion.getMapObject() : null;
                bindMapObjectEvents();
                updateMap();
            });
        });

        $(document).off("spatialmapinitialized.routeMapInit").on("spatialmapinitialized.routeMapInit", function (event) {
            const regionId = $(event.target).closest("[id]").attr("id");
            mapRegion = getApexRegion(regionId) || resolveMapRegion();
            mapObject = mapRegion && mapRegion.getMapObject ? mapRegion.getMapObject() : null;
            bindMapObjectEvents();
            updateMap();
        });
    }

    function init() {
        if (initialized) {
            return;
        }
        initialized = true;
        bindEvents();
        initializeState();
    }

    window.routeMapPage = {
        init,
        addPointFromMapClick,
        addPointAtCenter,
        addPointFromManualInput,
        searchPlace,
        newRoute: resetRoute,
        recalculateRoute,
        syncItems
    };
})(apex.jQuery, apex);
